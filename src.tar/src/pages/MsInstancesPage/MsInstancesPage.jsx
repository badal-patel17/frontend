import Sidebar from "../../components/sidebar/Sidebar";
import Navbar from "../../components/navbar/Navbar";
import "./msInstancesPage.scss";

import { useEffect, useState } from "react";

const API_BASE = "http://localhost:8070/vfort/api";

const MsInstancesPage = () => {
    const [data, setData] = useState([]);

    useEffect(() => {
        loadMsInstances();
    }, []);

    const loadMsInstances = async () => {
        try {
            const response = await fetch(
                `${API_BASE}/ms-instances`
            );

            const result = await response.json();

            setData(result || []);
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <div className="msInstancesPage">
            <Sidebar />

            <div className="homeContainer">
                <Navbar />

                <div className="pageHeader">
                    <h1>MS Instances</h1>
                    <p>Monitor microservice execution status</p>
                </div>

                <table>
                    <thead>
                    <tr>
                        <th>Step Instance</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Duration</th>
                        <th>Status</th>
                    </tr>
                    </thead>

                    <tbody>
                    {data.map(item => (
                        <tr key={item.id}>
                            <td>{item.step_instance_id}</td>
                            <td>{item.start_time}</td>
                            <td>{item.end_time}</td>
                            <td>{item.time_taken}</td>
                            <td>{item.status}</td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default MsInstancesPage;