// src/components/navbar/Navbar.jsx
import './navbar.scss';
import DarkModeOutlinedIcon          from '@mui/icons-material/DarkModeOutlined';
import LightModeOutlinedIcon         from '@mui/icons-material/LightModeOutlined';
import AccountCircle                 from '@mui/icons-material/AccountCircle';
import { Square }                    from '@mui/icons-material';
import { DarkModeContext }           from '../../context/darkModeContext';
import { useContext }                from 'react';

const Navbar = () => {
  const { darkMode, dispatch } = useContext(DarkModeContext);

  return (
    <header className="navbar" role="banner">
      <div className="navbar__inner">
        {/* Brand */}
        <div className="navbar__brand">
          <Square sx={{ color: '#e00000', fontSize: 18 }} />
          <div className="navbar__title-group">
            <span className="navbar__title">VI-FORT</span>
            <span className="navbar__version">Sandbox Env</span>
          </div>
        </div>

        {/* Actions */}
        <div className="navbar__actions">
          <button
            className="navbar__icon-btn"
            onClick={() => dispatch({ type: 'TOGGLE' })}
            aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
            title={darkMode ? 'Light mode' : 'Dark mode'}
          >
            {darkMode
              ? <LightModeOutlinedIcon sx={{ fontSize: 22 }} />
              : <DarkModeOutlinedIcon  sx={{ fontSize: 22 }} />}
          </button>
          <AccountCircle sx={{ fontSize: 32, color: '#3E424B', cursor: 'pointer' }} aria-label="User profile" />
        </div>
      </div>
    </header>
  );
};

export default Navbar;
