// src/components/featured/Featured.jsx

import React, { useMemo } from "react";
import "./featured.scss";

const getOrderId = item =>
    item?.orderId ||
    item?.order_id ||
    item?.id ||
    "";

const getStatus = item =>
    item?.status ||
    item?.errorClassification ||
    item?.falloutType ||
    "OPEN";

const getDateValue = item =>
    item?.createdAt ||
    item?.lastSeenAt ||
    item?.firstSeenAt ||
    item?.lastFailedAt ||
    item?.firstFailedAt ||
    item?.resolvedAt ||
    null;

const formatDate = value => {
  if (!value) {
    return "No timestamp";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "Invalid timestamp";
  }

  return date.toLocaleString();
};

const trimText = (value, max = 90) => {
  if (!value) {
    return "";
  }

  const text = String(value);

  if (text.length <= max) {
    return text;
  }

  return `${text.slice(0, max)}...`;
};

const Featured = ({
                    orders = [],
                    failedOrders = [],
                    unmappedFaults = [],
                    manualReviews = [],
                    metrics = {}
                  }) => {
  const priorityWorklist = useMemo(() => {
    const failedItems = failedOrders.map(item => ({
      orderId: getOrderId(item),
      type: "Failed Order",
      status: getStatus(item),
      reason:
          item.errorMessage ||
          item.errorCode ||
          item.errorClassification ||
          "Order failed during processing",
      timestamp: getDateValue(item),
      priority: 1
    }));

    const reviewItems = manualReviews.map(item => ({
      orderId: getOrderId(item),
      type: "Manual Review",
      status: getStatus(item),
      reason:
          item.lastError ||
          item.falloutType ||
          item.errorClassification ||
          "Manual validation required",
      timestamp: getDateValue(item),
      priority: 2
    }));

    const unmappedItems = unmappedFaults.map(item => ({
      orderId: getOrderId(item),
      type: "Unmapped Fault",
      status: getStatus(item),
      reason:
          item.errorMessage ||
          item.formId ||
          item.mappedProcessKey ||
          "Unknown fallout pattern",
      timestamp: getDateValue(item),
      priority: 3
    }));

    return [
      ...failedItems,
      ...reviewItems,
      ...unmappedItems
    ]
        .filter(item => item.orderId)
        .sort((a, b) => {
          if (a.priority !== b.priority) {
            return a.priority - b.priority;
          }

          if (!a.timestamp && !b.timestamp) {
            return 0;
          }

          if (!a.timestamp) {
            return 1;
          }

          if (!b.timestamp) {
            return -1;
          }

          return new Date(b.timestamp) - new Date(a.timestamp);
        })
        .slice(0, 6);
  }, [failedOrders, manualReviews, unmappedFaults]);

  const rootCauseSignals = useMemo(() => {
    const categoryMap = {};

    failedOrders.forEach(item => {
      const key =
          item.errorClassification ||
          item.errorCode ||
          item.failedStep ||
          item.status ||
          "FAILED_ORDER";

      categoryMap[key] = (categoryMap[key] || 0) + 1;
    });

    unmappedFaults.forEach(item => {
      const key =
          item.mappedProcessKey ||
          item.formId ||
          item.status ||
          "UNMAPPED_FAULT";

      categoryMap[key] = (categoryMap[key] || 0) + 1;
    });

    manualReviews.forEach(item => {
      const key =
          item.errorClassification ||
          item.falloutType ||
          item.status ||
          "MANUAL_REVIEW";

      categoryMap[key] = (categoryMap[key] || 0) + 1;
    });

    return Object.entries(categoryMap)
        .map(([name, count]) => ({
          name,
          count
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 6);
  }, [failedOrders, unmappedFaults, manualReviews]);

  const operationalRecommendations = useMemo(() => {
    const recommendations = [];

    if (failedOrders.length > 0) {
      recommendations.push({
        title: "Investigate failed orders first",
        detail:
            "Failed orders are blocking order progression. Review retry eligibility and recovery handling first.",
        severity: "critical"
      });
    }

    if (manualReviews.length > 0) {
      recommendations.push({
        title: "Clear manual review backlog",
        detail:
            "Manual review items require operator decision before the order journey can continue.",
        severity: "warning"
      });
    }

    if (unmappedFaults.length > 0) {
      recommendations.push({
        title: "Map unknown fallout patterns",
        detail:
            "Unmapped faults need classification so automation can route similar issues correctly next time.",
        severity: "info"
      });
    }

    if (
        failedOrders.length === 0 &&
        manualReviews.length === 0 &&
        unmappedFaults.length === 0
    ) {
      recommendations.push({
        title: "No fallout action required",
        detail:
            "No active failed, unmapped or manual review items were found in the backend data.",
        severity: "healthy"
      });
    }

    return recommendations.slice(0, 3);
  }, [failedOrders, manualReviews, unmappedFaults]);

  const dataIntelligence = useMemo(() => {
    const falloutItems =
        failedOrders.length +
        unmappedFaults.length +
        manualReviews.length;

    const duplicateLoad =
        metrics.distinctOrders === 0
            ? 0
            : Math.max(
                falloutItems - metrics.distinctOrders,
                0
            );

    return {
      distinctOrderCount: metrics.distinctOrders || 0,
      omsOrderCount: metrics.omsOrders || orders.length,
      falloutItemCount: metrics.falloutItems || falloutItems,
      duplicateLoad
    };
  }, [
    orders,
    failedOrders,
    unmappedFaults,
    manualReviews,
    metrics
  ]);

  return (
      <div className="featured featured--command-center">

        <div className="command-card command-card--next-action">
          <div className="command-card__header">
            <div>
              <h3>Operational Command Center</h3>
              <p>
                Recommended next actions based on live fallout queues.
              </p>
            </div>

            <span className="command-badge">
            Live
          </span>
          </div>

          <div className="recommendation-list">
            {operationalRecommendations.map((item, index) => (
                <div
                    className={`recommendation-item ${item.severity}`}
                    key={`${item.title}-${index}`}
                >
                  <div className="recommendation-marker" />

                  <div>
                    <strong>{item.title}</strong>
                    <span>{item.detail}</span>
                  </div>
                </div>
            ))}
          </div>
        </div>

        <div className="command-card command-card--data-intel">
          <h3>Data Intelligence</h3>

          <div className="data-intel-grid">
            <div>
              <span>Distinct Orders</span>
              <strong>{dataIntelligence.distinctOrderCount}</strong>
            </div>

            <div>
              <span>OMS Orders</span>
              <strong>{dataIntelligence.omsOrderCount}</strong>
            </div>

            <div>
              <span>Fallout Items</span>
              <strong>{dataIntelligence.falloutItemCount}</strong>
            </div>

            <div>
              <span>Duplicate Load</span>
              <strong>{dataIntelligence.duplicateLoad}</strong>
            </div>
          </div>

          <p className="data-intel-note">
            Distinct Orders avoids misleading totals when the same order appears in multiple fallout queues.
          </p>
        </div>

        <div className="command-card command-card--worklist">
          <h3>Priority Worklist</h3>

          <div className="worklist">
            {priorityWorklist.length === 0 ? (
                <p className="empty-state">
                  No priority work items available.
                </p>
            ) : (
                priorityWorklist.map((item, index) => (
                    <div
                        className="worklist-row"
                        key={`${item.type}-${item.orderId}-${index}`}
                    >
                      <div className="worklist-main">
                        <strong>{item.orderId}</strong>
                        <span>{trimText(item.reason)}</span>
                      </div>

                      <div className="worklist-meta">
                  <span
                      className={`type-chip ${item.type
                          .replace(/\s+/g, "-")
                          .toLowerCase()}`}
                  >
                    {item.type}
                  </span>

                        <small>{formatDate(item.timestamp)}</small>
                      </div>
                    </div>
                ))
            )}
          </div>
        </div>

        <div className="command-card command-card--root-cause">
          <h3>Root Cause Signals</h3>

          <div className="root-cause-list">
            {rootCauseSignals.length === 0 ? (
                <p className="empty-state">
                  No root cause signals available.
                </p>
            ) : (
                rootCauseSignals.map((item, index) => (
                    <div
                        className="root-cause-row"
                        key={`${item.name}-${index}`}
                    >
                      <span>{item.name}</span>
                      <strong>{item.count}</strong>
                    </div>
                ))
            )}
          </div>
        </div>

      </div>
  );
};

export default Featured;